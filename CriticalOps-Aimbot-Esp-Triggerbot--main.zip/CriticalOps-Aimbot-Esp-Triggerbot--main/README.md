# CriticalOps-Aimbot-Esp-Triggerbot-
A source for aimbot esp and triggerbot for Critical Ops version 1.38.0f2184

# Disclaimer
The code is not the best it could be, have fun implementing this
